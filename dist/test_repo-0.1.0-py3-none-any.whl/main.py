def main():
    print("Hello from test-repo!")


if __name__ == "__main__":
    main()
